

#define TAM_TOKEN 512


extern char token[TAM_TOKEN];




typedef struct {
	int  size;
	char type[256];
	char names[128][256]; 
} VarPkg;

void VarPkg_init(VarPkg* this);
void VarPkg_add(VarPkg* this, char* name);
//void VarPkg_setType(VarPkg* this, char* type);
//void VarPkg_clean(VarPkg* this);
void VarPkg_write(VarPkg* this, char* type);

#define ITYPE_VAR   1
#define ITYPE_OP    2
#define ITYPE_CONST 3
#define ITYPE_ENDP  4


typedef struct {
	int  type;
	char name[256];
} Item;

typedef struct {
	int  size;
	Item stack[128];
} Code;

void  Code_push(Code* this, int type, char* name);
Item* Code_pop(Code* this);
void  Code_useConst(Code* this,  char* name);
void  Code_useVar(Code* this,  char* name);
void  Code_useOp (Code* this,  char* name);

void  Code_write(Code* this, int line_number);



