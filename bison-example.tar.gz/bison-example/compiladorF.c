#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "compilador.h"




void VarPkg_init(VarPkg* this){
	this->size = 0;
}

void VarPkg_add(VarPkg* this, char* name){
	strcpy(this->names[this->size++], name);
}

void VarPkg_write(VarPkg* this, char* type){
	int i;
	for (i=0; i<this->size; i++){
		printf("{name='%s';type='%s'};", this->names[i], type);
	}
	this->size = 0;
}



void Code_init(Code* this){
}

void Code_push(Code* this, int type, char* name){
	this->stack[this->size].type = type;
	strcpy(this->stack[this->size].name,name);
	this->size++; 
}

Item* Code_pop(Code* this){
	return &this->stack[--this->size];
}

void  Code_useConst(Code* this,  char* name){
	Code_push(this, ITYPE_CONST, name);
}

void  Code_useVar(Code* this,  char* name){
	Code_push(this, ITYPE_VAR, name);
}

void  Code_useOp(Code* this,  char* name){
	Code_push(this, ITYPE_OP, name);
}





void  Code_write(Code* this, int line_number){
	void  write_rec(Code* this){
		if (this->size == 0)
			return;
		Item* item = Code_pop(this);
		if (item->type == ITYPE_CONST){
			printf("Cst{val='%s'};",  item->name);
		} else if (item->type == ITYPE_VAR){
			printf("Var{name='%s'};",  item->name);
		} else if (item->type == ITYPE_OP){
			printf("Op{ak=");
			write_rec(this);
			printf("no=");
			write_rec(this);
			printf("op='%s'};",item->name);
		}
	}


	if (this->size == 0)
		return;
	if ( this->size == 1){
		Item* item = Code_pop(this);
		if (item->type == ITYPE_VAR){
			printf("Var{name='%s'};",  item->name);
		}
	} else {
		Item* item = Code_pop(this);
		printf("Line{num=%d;", line_number);
		if (item->type == ITYPE_OP){
			printf("ak=");
			write_rec(this);
			printf("no=");
			write_rec(this);
			printf("op='%s'",item->name);
		}
		printf("};");
	}
}






